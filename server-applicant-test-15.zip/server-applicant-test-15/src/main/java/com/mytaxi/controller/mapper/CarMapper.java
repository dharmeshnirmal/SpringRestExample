package com.mytaxi.controller.mapper;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;

public class CarMapper
{
    public static CarDO makeCarDO(CarDTO driverDTO)
    {
        return new CarDO(
            driverDTO.getLicensePlate(), driverDTO.getSeatCount(), driverDTO.getConvertible(), driverDTO.getRating(), driverDTO.getEngineType(), driverDTO.getManufacturer());
    }


    public static CarDTO makeCarDTO(CarDO driverDO)
    {
        CarDTO.CarDTOBuilder driverDTOBuilder = CarDTO.newBuilder()
            .setId(driverDO.getId())
            .setLicensePlate(driverDO.getLicensePlate())
            .setSeatCount(driverDO.getSeatCount())
            .setConvertible(driverDO.getConvertible())
            .setRating(driverDO.getRating())
            .setEngineType(driverDO.getEngineType())
            .setManufacturer(driverDO.getManufacturer());

        return driverDTOBuilder.createCarDTO();
    }


    public static List<CarDTO> makeCarDTOList(Collection<CarDO> drivers)
    {
        return drivers.stream()
            .map(CarMapper::makeCarDTO)
            .collect(Collectors.toList());
    }
}
