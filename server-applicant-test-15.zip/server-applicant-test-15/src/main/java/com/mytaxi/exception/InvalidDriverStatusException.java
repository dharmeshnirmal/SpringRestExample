package com.mytaxi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Driver status is invalid for this operation.")
public class InvalidDriverStatusException extends RuntimeException
{
    static final long serialVersionUID = -3387516993334229948L;


    public InvalidDriverStatusException(String message)
    {
        super(message);
    }

}
