package com.mytaxi.datatransferobject;

import com.mytaxi.domainvalue.OnlineStatus;

public class DriverSerachDTO
{
   
    private String username;

    private OnlineStatus onlineStatus;
    
    private String licensePlate;
    
    private Float rating;
    
    private Integer seatCount;
    
    
    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public OnlineStatus getOnlineStatus()
    {
        return onlineStatus;
    }

    public void setOnlineStatus(OnlineStatus onlineStatus)
    {
        this.onlineStatus = onlineStatus;
    }

    public String getLicensePlate()
    {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate)
    {
        this.licensePlate = licensePlate;
    }

    public Float getRating()
    {
        return rating;
    }

    public void setRating(Float rating)
    {
        this.rating = rating;
    }

    public Integer getSeatCount()
    {
        return seatCount;
    }

    public void setSeatCount(Integer seatCount)
    {
        this.seatCount = seatCount;
    }

    public DriverSerachDTO(String username, OnlineStatus onlineStatus, String licensePlate, Float rating, Integer seatCount)
    {
        super();
        this.username = username;
        this.onlineStatus = onlineStatus;
        this.licensePlate = licensePlate;
        this.rating = rating;
        this.seatCount = seatCount;
    }
    
}
