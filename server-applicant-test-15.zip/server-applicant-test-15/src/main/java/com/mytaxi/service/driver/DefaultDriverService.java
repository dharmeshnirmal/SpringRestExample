package com.mytaxi.service.driver;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mytaxi.dataaccessobject.CarRepository;
import com.mytaxi.dataaccessobject.DriverRepository;
import com.mytaxi.datatransferobject.DriverSerachDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.exception.CarAlreadyInUseException;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.exception.InvalidDriverStatusException;

/**
 * Service to encapsulate the link between DAO and controller and to have business logic for some driver specific things.
 * <p/>
 */
@Service
public class DefaultDriverService implements DriverService
{

    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(DefaultDriverService.class);

    private final DriverRepository driverRepository;
    private final CarRepository carRepository;


    public DefaultDriverService(final DriverRepository driverRepository, final CarRepository carRepository)
    {
        this.driverRepository = driverRepository;
        this.carRepository = carRepository;
    }


    /**
     * Selects a driver by id.
     *
     * @param driverId
     * @return found driver
     * @throws EntityNotFoundException if no driver with the given id was found.
     */
    @Override
    public DriverDO find(Long driverId) throws EntityNotFoundException
    {
        return findDriverChecked(driverId);
    }


    /**
     * Creates a new driver.
     *
     * @param driverDO
     * @return
     * @throws ConstraintsViolationException if a driver already exists with the given username, ... .
     */
    @Override
    public DriverDO create(DriverDO driverDO) throws ConstraintsViolationException
    {
        return save(driverDO);
    }


    private DriverDO save(DriverDO driverDO) throws ConstraintsViolationException
    {
        try
        {
            return driverRepository.save(driverDO);
        }
        catch (DataIntegrityViolationException e)
        {
            LOG.warn("Some constraints are thrown due to driver save", e);
            throw new ConstraintsViolationException(e.getMessage());
        }
    }


    /**
     * Deletes an existing driver by id.
     *
     * @param driverId
     * @throws EntityNotFoundException if no driver with the given id was found.
     */
    @Override
    @Transactional
    public void delete(Long driverId) throws EntityNotFoundException
    {
        DriverDO driverDO = findDriverChecked(driverId);
        driverDO.setDeleted(true);
    }


    /**
     * Update the location for a driver.
     *
     * @param driverId
     * @param longitude
     * @param latitude
     * @throws EntityNotFoundException
     * @throws ConstraintsViolationException 
     */
    @Override
    @Transactional
    public void updateLocation(long driverId, double longitude, double latitude) throws EntityNotFoundException, ConstraintsViolationException
    {
        DriverDO driverDO = findDriverChecked(driverId);
        driverDO.setCoordinate(new GeoCoordinate(latitude, longitude));
        save(driverDO);
    }


    /**
     * Find all drivers by online state.
     *
     * @param onlineStatus
     */
    @Override
    public List<DriverDO> find(OnlineStatus onlineStatus)
    {
        return driverRepository.findByOnlineStatus(onlineStatus);
    }


    private DriverDO findDriverChecked(Long driverId) throws EntityNotFoundException
    {
        return driverRepository.findById(driverId)
            .orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + driverId));
    }


    private CarDO findCarChecked(Long carId) throws EntityNotFoundException
    {
        return carRepository.findById(carId)
            .orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + carId));
    }


    /**
     * Assign car to driver, If carId passed null it will removed already assigned car to that driver. 
     *
     * @param driverId id of the driver
     * @param carId id of the car
     * @throws EntityNotFoundException if any of the id details will not found in the data base system will throw this exception.
     * @throws CarAlreadyInUseException if passed car id is already assigned to any driver, system will throw this exception. 
     */
    @Override
    public void assignCar(@Valid long driverId, Long carId) throws EntityNotFoundException, CarAlreadyInUseException
    {
        DriverDO driverDO = findDriverChecked(driverId);
        if (!OnlineStatus.ONLINE.equals(driverDO.getOnlineStatus()))
        {
            throw new InvalidDriverStatusException("Only online driver can select the car.");
        }
        if (null != carId)
        {
            CarDO carDO = findCarChecked(carId);
            if (null != carDO.getDriverDO())
            {
                throw new CarAlreadyInUseException("Car already in use with car id: " + carId);
            }
            driverDO.setCarDO(carDO);
        }
        else
        {
            driverDO.setCarDO(null);
        }
        try
        {
            save(driverDO);
        }
        catch (ConstraintsViolationException e)
        {
            // No action required 
        }
    }


    /**
     * Search driver details by the given search criteria 
     *
     * @param driverSerachDTO It contains multiple fields which define search criteria 
     * @return List of driverDOs as search results
     */
    @Override
    public List<DriverDO> searchDrivers(DriverSerachDTO driverSerachDTO)
    {
        return driverRepository.findAll(new Specification<DriverDO>()
        {

            private static final long serialVersionUID = 19809890808L;


            @Override
            public Predicate toPredicate(Root<DriverDO> root, CriteriaQuery<?> query, CriteriaBuilder cb)
            {
                List<Predicate> predicates = new ArrayList<>();
                if (null != driverSerachDTO.getUsername())
                {
                    predicates.add(cb.equal(root.get("username"), driverSerachDTO.getUsername()));
                }
                if (null != driverSerachDTO.getOnlineStatus())
                {
                    predicates.add(cb.equal(root.get("onlineStatus"), driverSerachDTO.getOnlineStatus()));
                }
                if (null != driverSerachDTO.getLicensePlate())
                {
                    predicates.add(cb.equal(root.get("carDO").get("licensePlate"), driverSerachDTO.getLicensePlate()));
                }
                if (null != driverSerachDTO.getRating())
                {
                    predicates.add(cb.equal(root.get("carDO").get("rating"), driverSerachDTO.getRating()));
                }
                if (null != driverSerachDTO.getSeatCount())
                {
                    predicates.add(cb.equal(root.get("carDO").get("seatCount"), driverSerachDTO.getSeatCount()));
                }
                return cb.and(predicates.toArray(new Predicate[0]));
            }
        });
    }

}
