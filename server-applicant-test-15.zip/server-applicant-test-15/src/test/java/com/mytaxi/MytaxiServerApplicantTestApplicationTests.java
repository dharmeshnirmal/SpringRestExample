package com.mytaxi;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mytaxi.dataaccessobject.CarRepository;
import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.datatransferobject.DriverDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.exception.CarAlreadyInUseException;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.exception.InvalidDriverStatusException;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = MytaxiServerApplicantTestApplication.class)
@AutoConfigureMockMvc
public class MytaxiServerApplicantTestApplicationTests
{

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper = new ObjectMapper();


    @Test
    public void contextLoads()
    {}


    @Test
    public void getCarTest() throws Exception
    {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/cars/1")).andExpect(status().isOk()).andReturn();
        CarDTO carDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), CarDTO.class);
        Assert.assertNotNull(carDTO);
        Assert.assertEquals(Long.valueOf(1), carDTO.getId());
    }


    @Test
    public void getCarFailTest() throws Exception
    {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/cars/100")).andExpect(status().isBadRequest()).andReturn();
        Assert.assertEquals(EntityNotFoundException.class, mvcResult.getResolvedException().getClass());
        Assert.assertEquals("Could not find entity with id: 100", mvcResult.getResolvedException().getMessage());
    }


    @Test
    public void createCarTest() throws JsonProcessingException, Exception
    {
        CarDTO requestCarDTO = populateCarDTO("GJ 01 1100");

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/cars")
            .content(objectMapper.writeValueAsString(requestCarDTO)).contentType(APPLICATION_JSON_UTF8))
            .andExpect(status().isCreated()).andReturn();
        CarDTO carDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), CarDTO.class);

        Assert.assertNotNull(carDTO);
        Assert.assertNotNull(carDTO.getId());

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/cars/" + carDTO.getId())).andExpect(status().isOk()).andReturn();
        CarDTO getCarDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), CarDTO.class);
        Assert.assertNotNull(getCarDTO);
        Assert.assertEquals(carDTO.getId(), getCarDTO.getId());
    }


    @Test
    public void createCarFailTest() throws JsonProcessingException, Exception
    {
        CarDTO requestCarDTO = populateCarDTO("GJ 1 1000");
        // Creating car with same licensePlate
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/cars")
            .content(objectMapper.writeValueAsString(requestCarDTO)).contentType(APPLICATION_JSON_UTF8))
            .andExpect(status().isBadRequest()).andReturn();

        Assert.assertEquals(ConstraintsViolationException.class, mvcResult.getResolvedException().getClass());
        Assert.assertTrue(mvcResult.getResolvedException().getMessage().contains("could not execute statement"));

    }


    @Test
    public void deleteCarTest() throws JsonProcessingException, Exception
    {
        CarDTO requestCarDTO = populateCarDTO("GJ 01 1200");

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/cars")
            .content(objectMapper.writeValueAsString(requestCarDTO)).contentType(APPLICATION_JSON_UTF8))
            .andExpect(status().isCreated()).andReturn();
        CarDTO carDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), CarDTO.class);
        Assert.assertNotNull(carDTO);
        Assert.assertNotNull(carDTO.getId());

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/cars/" + carDTO.getId())).andExpect(status().isOk()).andReturn();

        CarDO carDO = carRepository.findById(carDTO.getId()).get();
        Assert.assertTrue(carDO.getDeleted());

    }


    @Test
    public void assignAndRemoveCarToDriverTest() throws Exception
    {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/5?carId=5")).andExpect(status().isOk()).andReturn();

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/drivers/5")).andExpect(status().isOk()).andReturn();
        DriverDTO getDriverDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), DriverDTO.class);

        Assert.assertNotNull(getDriverDTO);
        Assert.assertNotNull(getDriverDTO.getCarDTO());

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/5")).andExpect(status().isOk()).andReturn();

        // Passing null carId to remove car
        mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/drivers/5")).andExpect(status().isOk()).andReturn();
        getDriverDTO = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), DriverDTO.class);

        Assert.assertNotNull(getDriverDTO);
        Assert.assertNull(getDriverDTO.getCarDTO());

    }


    @Test
    public void assignAllreadyAssignedCarToOtherDriverTest() throws Exception
    {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/4?carId=4")).andExpect(status().isOk()).andReturn();

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/5?carId=4")).andExpect(status().isBadRequest()).andReturn();

        Assert.assertEquals(CarAlreadyInUseException.class, mvcResult.getResolvedException().getClass());
        Assert.assertEquals("Car already in use with car id: 4", mvcResult.getResolvedException().getMessage());

        mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/1?carId=1")).andExpect(status().isBadRequest()).andReturn();

        Assert.assertEquals(InvalidDriverStatusException.class, mvcResult.getResolvedException().getClass());
        Assert.assertEquals("Only online driver can select the car.", mvcResult.getResolvedException().getMessage());

    }


    @Test
    public void assignCarOfflineDriverTest() throws Exception
    {

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/1?carId=1")).andExpect(status().isBadRequest()).andReturn();

        Assert.assertEquals(InvalidDriverStatusException.class, mvcResult.getResolvedException().getClass());
        Assert.assertEquals("Only online driver can select the car.", mvcResult.getResolvedException().getMessage());

    }


    @Test
    public void assignCarEntityNotFoundExceptionTest() throws Exception
    {

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/100?carId=1")).andExpect(status().isBadRequest()).andReturn();

        Assert.assertEquals(EntityNotFoundException.class, mvcResult.getResolvedException().getClass());
        Assert.assertEquals("Could not find entity with id: 100", mvcResult.getResolvedException().getMessage());

    }


    @Test
    public void serachDriverTest() throws Exception
    {
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/v1/drivers/assigncar/6?carId=6")).andExpect(status().isOk()).andReturn();

        mvcResult =
            mockMvc
                .perform(MockMvcRequestBuilders.get("/v1/drivers/search?username=driver06&onlineStatus=ONLINE&licensePlate=GJ 1 6000&seatCount=4&rating=5.0"))
                .andExpect(status().isOk()).andReturn();
        DriverDTO[] driverDTOs = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), DriverDTO[].class);

        for (DriverDTO driverDTO : driverDTOs)
        {
            Assert.assertEquals("driver06", driverDTO.getUsername());
            Assert.assertEquals("GJ 1 6000", driverDTO.getCarDTO().getLicensePlate());
            Assert.assertEquals(Integer.valueOf(4), driverDTO.getCarDTO().getSeatCount());
            Assert.assertEquals(Float.valueOf(5f), driverDTO.getCarDTO().getRating());
        }

        //Zero result as searching with username = driver05
        mvcResult =
            mockMvc
                .perform(MockMvcRequestBuilders.get("/v1/drivers/search?username=driver05&onlineStatus=ONLINE&licensePlate=GJ 1 6000&seatCount=4&rating=5.0"))
                .andExpect(status().isOk()).andReturn();
        driverDTOs = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), DriverDTO[].class);
        Assert.assertEquals(0, driverDTOs.length);

    }


    private CarDTO populateCarDTO(String licensePlate)
    {
        return new CarDTO(null, licensePlate, 4, false, 4.0f, EngineType.DIESEL, "BMW");
    }

}
